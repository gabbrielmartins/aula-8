# 8-Diagnostico_de_Residuos-Normalidade
Verificando normalidade por meio de histogramas e teste Jarque-Bera
